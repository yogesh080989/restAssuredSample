# Virtual Developer — POC

This POC demonstrates an end-to-end pipeline that:
1. Loads a Markdown knowledge base (kb/*.md)
2. Builds a FAISS vector index of KB chunks
3. Pulls Jira story acceptance criteria (or accepts raw text) and retrieves relevant KB chunks
4. Calls an LLM to generate requirement-gap questions categorized as `Must/Should/Could`
5. Optionally posts the generated questions as a Jira comment

> This POC is intentionally simple and designed for extension.

## Quick start

1. Copy files into a project folder.
2. Create a virtualenv and install requirements:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

3. Populate `kb/` with `.md` files (small files are fine).
4. Set environment variables (see `.env.example`) or export them:

```bash
export OPENAI_API_KEY="sk-..."
export JIRA_BASE_URL="https://your-domain.atlassian.net"
export JIRA_EMAIL="your-email@example.com"
export JIRA_API_TOKEN="jira-api-token"
```

5. Build the KB index:

```bash
python scripts/build_index.py --kb_dir kb --index_path data/faiss.index --meta_path data/metadata.json
```

6. Run the API:

```bash
uvicorn app.main:app --reload --port 8000
```

7. Use the endpoint to process a story (see API docs).

## Files
- `app/` — FastAPI app + wiring
- `kb/` — place markdown files here
- `data/` — stores index and metadata (created by build script)
- `scripts/` — helper script to build index

## Notes
- Embeddings use `sentence-transformers` for the POC. You can swap to OpenAI embeddings by modifying `embeddings.py`.
- LLM calls use the OpenAI `openai` package. Swap models as needed.
