from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional
import os

from jira_client import JiraClient
from embeddings import FaissIndex
from gap_agent import GapAgent

app = FastAPI(title="Virtual Developer POC")

# Serve static frontend
app.mount("/static", StaticFiles(directory="static"), name="static")

INDEX_PATH = os.environ.get("INDEX_PATH", "data/faiss.index")
META_PATH = os.environ.get("META_PATH", "data/metadata.json")

index = None
agent = None
jira = None


class StoryInput(BaseModel):
    jira_key: Optional[str] = None
    acceptance_criteria: Optional[str] = None
    top_k: int = 5


class JiraPost(BaseModel):
    jira_key: str
    markdown: str


@app.on_event("startup")
def startup_event():
    global index, agent, jira
    index = FaissIndex(index_path=INDEX_PATH, meta_path=META_PATH)
    agent = GapAgent()
    jira = JiraClient()


@app.get("/", response_class=HTMLResponse)
async def root():
    return FileResponse("static/index.html")


@app.post("/process_story")
async def process_story(inp: StoryInput):
    ac_text = inp.acceptance_criteria
    if inp.jira_key and not ac_text:
        issue = jira.get_issue(inp.jira_key)
        if not issue:
            raise HTTPException(status_code=404, detail="Jira issue not found")
        ac_text = issue.get("fields", {}).get("description")

    if not ac_text:
        raise HTTPException(status_code=400, detail="Provide jira_key or acceptance_criteria")

    hits = index.search(ac_text, top_k=inp.top_k)
    top_chunks = [h["text"] for h in hits]
    result_md = agent.generate_gap_questions(ac_text, top_chunks)

    return {"questions_markdown": result_md}


@app.post("/send_to_jira")
async def send_to_jira(payload: JiraPost):
    if not jira.enabled:
        raise HTTPException(status_code=500, detail="Jira not configured")
    jira.post_comment(payload.jira_key, payload.markdown)
    return {"status": "posted"}
