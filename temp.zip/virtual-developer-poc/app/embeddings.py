# Embeddings module

class Embeddings:
    pass
