# Jira client module

class JiraClient:
    pass
