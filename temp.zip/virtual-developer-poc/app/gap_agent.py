import os
import time
import openai
import random

OPENAI_KEY = os.environ.get('OPENAI_API_KEY')
if OPENAI_KEY:
    openai.api_key = OPENAI_KEY


class GapAgent:
    def __init__(self, model: str = "gpt-4o-mini", max_retries: int = 5, initial_backoff: float = 2.0):
        self.model = model
        self.max_retries = max_retries
        self.initial_backoff = initial_backoff

    def _call_llm(self, prompt: str):
        """
        Call OpenAI with retry + backoff
        """
        for attempt in range(1, self.max_retries + 1):
            try:
                resp = openai.ChatCompletion.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=800,
                    temperature=0.2,
                )
                return resp['choices'][0]['message']['content']

            except openai.error.RateLimitError as e:
                wait = self.initial_backoff * (2 ** (attempt - 1)) + random.uniform(0, 1)
                print(f"[WARN] Rate limit hit. Retrying in {wait:.1f}s (attempt {attempt})")
                time.sleep(wait)

            except openai.error.ServiceUnavailableError as e:
                wait = self.initial_backoff * (2 ** (attempt - 1)) + random.uniform(0, 1)
                print(f"[WARN] Service unavailable. Retrying in {wait:.1f}s (attempt {attempt})")
                time.sleep(wait)

            except Exception as e:
                print(f"[ERROR] Unexpected LLM call error: {e}")
                if attempt == self.max_retries:
                    raise
                time.sleep(self.initial_backoff * attempt)

        raise RuntimeError("Max retries exceeded for LLM call")

    def generate_gap_questions(self, acceptance_criteria: str, kb_chunks: list):
        """
        Generate structured requirement-gap questions with a richer template
        """
        kb_text = "\n\n---\n\n".join(kb_chunks)

        prompt = f"""
You are a **senior requirements analyst** helping developers refine user stories.

### Input
**Acceptance Criteria (raw text):**
{acceptance_criteria}

**Relevant Knowledge Base excerpts:**
{kb_text}

### Task
1. Analyze the acceptance criteria vs KB to find missing or ambiguous requirements.
2. Ask clarification questions that would help developers close these gaps.
3. Categorize each question into:
   - **Must** → blockers, story cannot be implemented without answer.
   - **Should** → important details, not blockers but affect correctness/quality.
   - **Could** → optional clarifications or potential improvements.

### Output format (Markdown only)
