# Knowledge base loader module

class KBLoader:
    pass
