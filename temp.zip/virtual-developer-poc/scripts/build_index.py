import argparse
import os
from app.kb_loader import load_md_files, chunk_text
from app.embeddings import FaissIndex

def main(kb_dir, index_path, meta_path, chunk_max_tokens=300):
    docs = load_md_files(kb_dir)
    chunks = []
    for doc in docs:
        cks = chunk_text(doc['text'], max_tokens=chunk_max_tokens)
        for i, c in enumerate(cks):
            chunks.append({
                'text': c,
                'path': doc['path'],
                'chunk_id': f"{os.path.basename(doc['path'])}#chunk{i}"
            })
    idx = FaissIndex(index_path=index_path, meta_path=meta_path)
    idx.build(chunks)
    print(f"Built index with {len(chunks)} chunks")


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--kb_dir', default='kb')
    p.add_argument('--index_path', default='data/faiss.index')
    p.add_argument('--meta_path', default='data/metadata.json')
    args = p.parse_args()
    os.makedirs(os.path.dirname(args.index_path) or '.', exist_ok=True)
    os.makedirs(os.path.dirname(args.meta_path) or '.', exist_ok=True)
    main(args.kb_dir, args.index_path, args.meta_path)
