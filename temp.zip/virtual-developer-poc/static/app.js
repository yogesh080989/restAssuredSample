async function generate() {
  const jiraKey = document.getElementById("jira_key").value.trim();
  const acceptance = document.getElementById("acceptance").value.trim();

  const resp = await fetch("/process_story", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jira_key: jiraKey || null,
      acceptance_criteria: acceptance || null,
      top_k: 5
    })
  });

  const data = await resp.json();
  if (resp.ok) {
    document.getElementById("results").style.display = "block";
    document.getElementById("markdown").value = data.questions_markdown;
  } else {
    alert("Error: " + data.detail);
  }
}

async function sendToJira() {
  const jiraKey = document.getElementById("jira_key").value.trim();
  const markdown = document.getElementById("markdown").value;

  const resp = await fetch("/send_to_jira", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jira_key: jiraKey, markdown: markdown })
  });

  const data = await resp.json();
  if (resp.ok) {
    alert("Posted to Jira!");
  } else {
    alert("Error: " + data.detail);
  }
}
