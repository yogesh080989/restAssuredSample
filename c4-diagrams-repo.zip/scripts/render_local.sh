#!/usr/bin/env bash
set -euo pipefail

OUT_DIR=${1:-out}
mkdir -p "$OUT_DIR"

if command -v docker >/dev/null 2>&1; then
  echo "[render] Using Dockerized PlantUML"
  docker run --rm -v "$PWD:/data" plantuml/plantuml -tsvg /data/diagrams/*.puml -o /data/"$OUT_DIR"
else
  echo "[render] Docker not found. Falling back to local java -jar plantuml.jar"
  if [ ! -f plantuml.jar ]; then
    echo "Missing plantuml.jar in repo root. Download from https://plantuml.com/download"
    exit 1
  fi
  java -jar plantuml.jar -tsvg diagrams/*.puml -o "$OUT_DIR"
fi

echo "[render] Done. SVGs in $OUT_DIR"
