import json, os, sys, requests
from pathlib import Path
import argparse

BASE   = os.environ.get("CONFLUENCE_BASE", "").rstrip("/")
EMAIL  = os.environ.get("CONFLUENCE_EMAIL", "")
TOKEN  = os.environ.get("CONFLUENCE_TOKEN", "")
PAGEID = os.environ.get("CONFLUENCE_PAGE_ID", "")

def require_env(var, value):
    if not value:
        print(f"Missing environment variable: {var}", file=sys.stderr)
        sys.exit(2)

def attach_or_update(page_id: str, file_path: Path, dry_run: bool = False):
    name = file_path.name
    url  = f"{BASE}/rest/api/content/{page_id}/child/attachment"
    if dry_run:
        print(f"[dry-run] Would upload/attach: {name}")
        return None

    # Check if attachment already exists
    r = requests.get(url, params={"filename": name, "expand": "version"}, auth=(EMAIL, TOKEN))
    r.raise_for_status()
    results = r.json().get("results", [])
    if results:
        attach_id = results[0]["id"]
        upload_url = f"{BASE}/rest/api/content/{page_id}/child/attachment/{attach_id}/data"
    else:
        upload_url = url

    with open(file_path, "rb") as fh:
        files = {"file": (name, fh, "image/svg+xml")}
        r = requests.post(upload_url, auth=(EMAIL, TOKEN), files=files)
        r.raise_for_status()
        return results[0]["id"] if results else r.json()["results"][0]["id"]

def get_page(page_id: str):
    url = f"{BASE}/rest/api/content/{page_id}"
    r = requests.get(url, params={"expand":"version,body.storage"}, auth=(EMAIL, TOKEN))
    r.raise_for_status()
    return r.json()

def update_page_with_images(page_id: str, filenames, dry_run: bool = False):
    if dry_run:
        print(f"[dry-run] Would ensure these images are referenced in page body: {filenames}")
        return
    page = get_page(page_id)
    ver  = page["version"]["number"] + 1
    body = page["body"]["storage"]["value"]

    for name in filenames:
        macro = f'<ac:image><ri:attachment ri:filename="{name}"/></ac:image>'
        if name not in body:
            body += f"<p>{macro}</p>"

    url = f"{BASE}/rest/api/content/{page_id}"
    payload = {
        "id": page_id,
        "type": "page",
        "title": page["title"],
        "version": {"number": ver, "minorEdit": True},
        "body": {"storage": {"value": body, "representation": "storage"}}
    }
    r = requests.put(url, auth=(EMAIL, TOKEN), headers={"Content-Type":"application/json"}, data=json.dumps(payload))
    r.raise_for_status()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out_dir", nargs="?", default="out")
    ap.add_argument("--dry-run", action="store_true", help="Don't call Confluence APIs; just print actions")
    args = ap.parse_args()

    require_env("CONFLUENCE_BASE", BASE)
    require_env("CONFLUENCE_EMAIL", EMAIL)
    require_env("CONFLUENCE_TOKEN", TOKEN)
    require_env("CONFLUENCE_PAGE_ID", PAGEID)

    out = Path(args.out_dir)
    svgs = sorted(out.glob("*.svg"))
    if not svgs:
        print("No SVGs found in", out)
        sys.exit(1)

    names = []
    for svg in svgs:
        print("Uploading", svg.name if not args.dry_run else f"(dry) {svg.name}")
        attach_or_update(PAGEID, svg, dry_run=args.dry_run)
        names.append(svg.name)

    update_page_with_images(PAGEID, names, dry_run=args.dry_run)
    print("Done.")

if __name__ == "__main__":
    main()
