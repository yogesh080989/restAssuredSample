# C4 Diagrams → Confluence (Automated)

This repo renders C4-PlantUML diagrams to SVG and uploads them to a Confluence page.

## Quick start (local)

### Prereqs
- **Either** Docker (recommended) **or** Java + `plantuml.jar`
- Python 3.9+ (`requests` library)

### Render locally
```bash
./scripts/render_local.sh            # SVGs will be in ./out
# or specify a custom output dir:
./scripts/render_local.sh dist
```

### Preview
Open the generated `out/*.svg` in your browser.

### Dry-run Confluence publish (no changes on server)
```bash
export CONFLUENCE_BASE="https://<your>.atlassian.net/wiki"
export CONFLUENCE_EMAIL="<you@company.com>"
export CONFLUENCE_TOKEN="<api-token>"
export CONFLUENCE_PAGE_ID="<123456789>"

python scripts/publish_to_confluence.py out --dry-run
```

### Real publish to Confluence
```bash
python scripts/publish_to_confluence.py out
```

## GitHub Actions (CI)
- On every push to `main`, CI will:
  1) Render `diagrams/*.puml` to `out/*.svg`
  2) Upload to Confluence and ensure images appear on the page

Set these **secrets** in GitHub:
- `CONFLUENCE_BASE`
- `CONFLUENCE_EMAIL`
- `CONFLUENCE_TOKEN`
- `CONFLUENCE_PAGE_ID`

## Diagrams
Edit or add files in `diagrams/`. All `.puml` files are rendered.
