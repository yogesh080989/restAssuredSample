---
name: java-spring-debugging
description: Expert troubleshooting for Spring Boot services.
---

Steps:

1. Check logs for stacktrace root.
2. Validate bean wiring.
3. Inspect REST mapping.
4. Check serialization/deserialization.
5. Investigate async/event processing.
