---
name: rag-debugging
description: Diagnose RAG pipeline issues including retrieval failures, hallucinations, embedding problems.
---

Process:

1. Verify indexing pipeline
2. Check chunking strategy
3. Evaluate embedding model
4. Inspect vector search parameters
5. Check prompt context assembly
6. Suggest optimization:
   - reranking
   - hybrid search
   - semantic filters
