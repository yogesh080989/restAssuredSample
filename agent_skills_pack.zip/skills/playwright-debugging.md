---
name: playwright-debugging
description: Debug Playwright scripts and agent-based browser automation.
---

Steps:

1. Validate selectors.
2. Check page load timing.
3. Inspect network calls.
4. Analyze HAR file.
5. Fix flaky tests.
