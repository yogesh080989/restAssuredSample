---
name: alertprocessor-analysis
description: Analyze DPMS AlertProcessor batch issues.
---

Process:

1. Identify batch failure stage.
2. Check upstream dependency.
3. Validate message format.
4. Analyze Splunk alerts.
5. Check retry logic.
6. Suggest fix.
